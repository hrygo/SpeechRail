"""Music model implementations."""
